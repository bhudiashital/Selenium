import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by bhudi on 13/11/2016.
 */
public class GmailRegister

{

    public static String randomDate()
    {
        DateFormat format=new SimpleDateFormat("ddMMyyHHss");
        return format.format(new Date());

    }
    protected static WebDriver driver;
    public static void main(String[] args)
    {
        System.out.println("Gmail Registration");
        // This will load Firefox Drivers
        WebDriver driver=new FirefoxDriver();
        // This will open the Google page.
        String email ="software999585"+randomDate();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.google.com/gmail");

        driver.findElement(By.linkText("Create account")).click();
        System.out.println("Create An Account is displaying");

//        driver.findElement(By.id("FirstName")).clear();
        driver.findElement(By.id("FirstName")).sendKeys("Soft");
        driver.findElement(By.id("LastName")).sendKeys("Ware");
        System.out.println("This is completed");
        driver.findElement(By.id("GmailAddress")).sendKeys(email);
        driver.findElement(By.id("Passwd")).sendKeys("Shital123");
        driver.findElement(By.id("PasswdAgain")).sendKeys("Shital123");

        System.out.println("Working upto Confirm Password.");

//       Select Date of Birth // NOT WORKING
//      String string ="item";
//        protected String waitForElement(string);
//        {
//        WebDriverWait wait = new WebDriverWait(driver,30);
//        WebElement element = wait.until(
//                ExpectedConditions.elementToBeClickable(By.id(:1)));
//        return 01;
//    }
        driver.findElement(By.id("BirthMonth")).click();




        driver.findElement(By.id(":3")).click();
//        Select month = new Select(driver.findElement(By.class"August"));



//        driver.close();


    }

//    private static void click() {
//    }
}
