import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.server.browserlaunchers.GoogleChromeLauncher;

import java.util.List;
import java.util.Set;

/**
 * Created by bhudi on 16/11/2016.
 */
public class TubeStationsAutomated
{
    public static void main(String[] args)
    {
        WebDriver driver=new FirefoxDriver();


        System.out.println("Enter any station to check if its from Zone 1 and check number of lines coming to that station.");
        driver.get("https://www.tfl.gov.uk");



    }
}
