import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by bhudi on 15/11/2016.
 * Homework : Opensourse Orange HRM: website: Registered user is able to log in or not?
 *
 */
public class OrangeHRM
{

    public static String randomDate()
    {
        DateFormat format=new SimpleDateFormat("ddMMyyHHssMM" +
                "");
        return format.format(new Date());

    }
    public static void main(String[] args)
    {
        System.out.println("Register a user in Orange HRM");

        WebDriver driver= new FirefoxDriver();
        driver.get("http://opensource.demo.orangehrmlive.com/");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        String username="AmitabhB"+randomDate();
        String eid= "666"+randomDate();

        driver.findElement(By.id("txtUsername")).sendKeys("admin");
        driver.findElement(By.id("txtPassword")).sendKeys("admin");
        driver.findElement(By.id("btnLogin")).click();
//        Logged in with Admin User.

        driver.findElement(By.id("menu_pim_viewPimModule")).click();
        driver.findElement(By.id("menu_pim_addEmployee")).click();

//        Adding new Employee

        driver.findElement(By.id("firstName")).sendKeys("Amitabh");
        driver.findElement(By.id("middleName")).sendKeys("H");
        driver.findElement(By.id("lastName")).sendKeys("Bachchan");
        driver.findElement(By.id("employeeId")).clear();
        driver.findElement(By.id("employeeId")).sendKeys(eid);
        driver.findElement(By.id("chkLogin")).click();

//        Name details added.

        driver.findElement(By.id("user_name")).sendKeys(username);
        driver.findElement(By.id("user_password")).sendKeys("123456");
        driver.findElement(By.id("re_password")).sendKeys("123456");
        driver.findElement(By.id("btnSave")).click();


        System.out.println("A new user account created successfully.");

//        User Created.

        driver.findElement(By.id("welcome")).click();
        driver.findElement(By.id("welcome-menu")).click();
        driver.findElement(By.linkText("Logout")).click();

//      User Logged out.

        driver.findElement(By.id("txtUsername")).sendKeys("AmitabhB");
        driver.findElement(By.id("txtPassword")).sendKeys("123456");
        driver.findElement(By.id("btnLogin")).click();


    }
}
