import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by bhudi on 13/11/2016.
 */
public class FIrstFile
{
    public static void main(String[] args) throws InterruptedException {

//        This will load Firefox Driver. Firefox must be open.
        WebDriver driver=new FirefoxDriver();

//        This will open gmail in Firefox browser.
        driver.get("https://www.google.co.uk/gmail");

        Thread.sleep(1000);
//        You can also use try catch instead of thread.sleep

        String actual=driver.getTitle();
        String expected="Gmail";

        if (expected.equals(actual))
        {
            System.out.println("Test Passed "+"The title of this website is "+expected);

        }
        else
        {
            System.out.println("Test FAILED.");
        }

        driver.close();

    }
}
