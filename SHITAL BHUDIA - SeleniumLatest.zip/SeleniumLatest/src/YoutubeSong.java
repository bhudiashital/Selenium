import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * Created by bhudi on 15/11/2016.
 * YOUTUBE HOMEWORK : SELECT YOUR FAVOURITE SONG IN YOUTUBE AND IT SHOULD BE AUTOMATICALLY.
 */
public class YoutubeSong
{
    public static void main(String[] args)
    {
        System.out.println("Playing my favourite song from YouTube.");

        WebDriver driver=new FirefoxDriver();
        driver.get("https://www.youtube.com");
        driver.manage().timeouts().implicitlyWait(10, SECONDS);

        System.out.println("Reaching upto here");

        driver.findElement(By.id("masthead-search-term")).sendKeys("Ruk Jana Nahin Tu Kahin Haar Ke Kanton Pe");
        driver.findElement(By.id("search-btn")).click();

        System.out.println("Song Selected and listed");

        driver.findElement(By.linkText("Ruk Jana Nahin Tu Kahin Haar Ke Kanton Pe { The Great Kishore Kumar } *Imtihaan *")).click();

        System.out.println("Selected song is playing....WOW");

        String actual=By.className("watch-title").findElement(driver).getText();
        String expected="Ruk Jana Nahin Tu Kahin Haar Ke Kanton Pe { The Great Kishore Kumar } *Imtihaan *";

        Assert.assertEquals(actual, expected);
        System.out.println("YouTube Test Passed");

    }
}
