import javafx.scene.input.DataFormat;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by bhudi on 13/11/2016.
 */
public class NopCommerce
{
    public static String randomDate()
    {
        DateFormat format=new SimpleDateFormat("ddMMyyHHss");
        return format.format(new Date());

    }
    public static void main(String[] args)
    {
        WebDriver driver=new FirefoxDriver();
        String email ="bhudiash"+randomDate()+"@gmail.com";
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.get("https://www.nopcommerce.com");

        driver.findElement(By.linkText("Register")).click();
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_txtFirstName")).sendKeys("Shital");
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_txtLastName")).sendKeys("Bhudia");
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Email")).sendKeys(email);
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_UserName")).sendKeys(email);
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Password")).sendKeys("123456");
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ConfirmPassword")).sendKeys("123456");
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm___CustomNav0_StepNextButton")).click();


        String actual=driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CompleteStepContainer_lblCompleteStep")).getText();
        String expected ="Your registration completed";

//       if(actual.equals(expected))
//       {
//           System.out.println("Your Test case Passed");
//       }
//    else
//           System.out.println("TEST FAILED.........DO IT AGAIN");

//        Assert.assertEquals(expected,actual,"\n\nConfirmation message is Incorrect");
        Assert.assertTrue(actual.equals(expected));
        System.out.println("Test Passed");


    driver.close();
    }
}
