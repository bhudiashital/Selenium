import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by bhudi on 15/11/2016.
 * Homework: SHOPPING BASKET: BUY ANY 3 ITEMS FROM ANY WEBSITE AND ADD TO BASKET. CHECK THE BASKET, IF ITS 3 ITEMS, IN THERE.
 */
public class ShoppingBasket
{
    public static void main(String[] args)
    {
        System.out.println("Shopping 3 items from www.Johnlewis.com and adding them to basket.");

        WebDriver driver=new FirefoxDriver();
        driver.get("https://www.johnlewis.com");

        driver.findElement(By.xpath(".//*[@id='cq-left-hppromo']/ul[2]/li[2]/a/h3")).click();
        driver.findElement(By.id("3081995-product-link-title")).click();
        driver.findElement(By.name("/atg/commerce/order/purchase/CartModifierFormHandler.addItemToOrder")).click();
        driver.findElement(By.xpath(".//*[@id='nn-nav-menu']/ul/li[8]/a/span[2]")).click();
        driver.findElement(By.xpath(".//*[@id='category-grid']/div/div[8]/div/section/a[1]")).click();
        driver.findElement(By.id("2895687-product-link-title")).click();
        driver.findElement(By.xpath(".//*[@id='prod-add-to-basket']/div[2]/div/fieldset[2]/div/span/input[11]")).click();
        driver.findElement(By.xpath(".//*[@id='nn-nav-menu']/ul/li[8]/a/span[2]")).click();
        driver.findElement(By.xpath(".//*[@id='category-grid']/div/div[8]/div/section/a[2]")).click();
        driver.findElement(By.xpath(".//*[@id='2593533-product-link']/img")).click();
        driver.findElement(By.xpath(".//*[@id='prod-add-to-basket']/div[2]/div/fieldset[2]/div/span/input[11]")).click();
        driver.findElement(By.linkText("Checkout")).click();

        String actual= By.cssSelector(".ver-mid.text").findElement(driver).getText();
        String expected="Basket - 3 items";

        Assert.assertTrue(expected.equals(actual));
        System.out.println("CONGRATULATIONS..........................Johnlewis Shopping test passed.");


//        Assert.assertFalse(expected!=(actual));
//        System.out.println("Test FAILED !!!! OMGGGGGGGG");


//        if(actual.equals(expected))
//       {
//           System.out.println("Your Test case Passed");
//       }
//         else {
//            System.out.println("TEST FAILED.........DO IT AGAIN");
//        }

//        driver.findElement(By.xpath(".//*[@id='basketForm']/div[4]/div[1]/div[1]/h1/span[2]"));



    }
}
